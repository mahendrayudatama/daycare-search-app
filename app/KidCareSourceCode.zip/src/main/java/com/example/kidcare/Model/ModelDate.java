package com.example.kidcare.Model;

public class ModelDate {
    String day;
    String date;

    public ModelDate(String day, String date) {
        this.day = day;
        this.date = date;
    }

    public String getDay() {
        return day;
    }

    public String getDate() {
        return date;
    }
}
