package com.example.kidcare;

public interface IRecyclerView {
    void OnItemClick(int position);
    void OnItemClick2(int position);
    void OnItemClick3(int position);
}
