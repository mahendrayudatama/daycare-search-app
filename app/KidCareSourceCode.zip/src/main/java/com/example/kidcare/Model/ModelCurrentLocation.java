package com.example.kidcare.Model;

public class ModelCurrentLocation {
    Double mText1;
    Double mText2;


    public ModelCurrentLocation(Double text1, Double text2) {
        mText1 = text1;
        mText2 = text2;
    }

    public Double getmText1() {
        return mText1;
    }

    public Double getmText2() {
        return mText2;
    }


}
