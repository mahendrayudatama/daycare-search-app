package com.example.kidcare.Model;

public class ModelMainAct {
    String currentChild;

    public String getCurrentChild() {
        return currentChild;
    }


    public ModelMainAct(String currentChild) {
        this.currentChild = currentChild;

    }
}
