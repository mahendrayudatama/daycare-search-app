package com.example.kidcare.Model;

public class ModelUrl {
    String Url;

    public void setUrl(String url) {
        Url = url;
    }

    public String getUrl() {
        return Url;
    }

    public ModelUrl(String url) {
        Url = url;
    }
}
